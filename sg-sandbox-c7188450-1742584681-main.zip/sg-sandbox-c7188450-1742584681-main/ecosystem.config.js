module.exports = {
  apps: [{
    name: 'nextjs',
    script: 'npm',
    args: 'run dev',
    autorestart: true,
  }]
};