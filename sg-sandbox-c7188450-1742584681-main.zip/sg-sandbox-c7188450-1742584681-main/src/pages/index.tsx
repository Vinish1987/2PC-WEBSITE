
import React from "react"
import Head from "next/head"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Calculator from "@/components/Calculator"
import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <>
      <Head>
        <title>2PC - Save, Earn Rewards, and Chill</title>
        <meta name="description" content="2% monthly returns. Capital-safe. Effortless." />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </Head>
      
      <main className="min-h-screen bg-white">
        {/* Navigation */}
        <nav className="container py-8 flex items-center justify-between">
          <div className="font-bold text-2xl">2PC</div>
          <div className="hidden md:flex items-center space-x-8">
            <a href="#" className="hover:text-primary transition-colors">Home</a>
            <a href="#how-it-works" className="hover:text-primary transition-colors">How It Works</a>
            <a href="#features" className="hover:text-primary transition-colors">Features</a>
            <a href="#calculator" className="hover:text-primary transition-colors">Calculator</a>
            <a href="#why-2pc" className="hover:text-primary transition-colors">Why 2PC</a>
            <a href="#join-us" className="hover:text-primary transition-colors">Join Us</a>
          </div>
          <Button className="bg-[#5D5FEF] hover:bg-[#4A4CD8] text-white rounded-full">DEMO</Button>
        </nav>

        {/* Hero Section */}
        <section className="relative min-h-[80vh] flex items-center">
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <Image 
              src="/242-m8zhz2yk.jpg" 
              alt="Hero Background" 
              fill 
              priority
              style={{ objectFit: "cover" }} 
            />
          </div>
          
          <div className="container relative z-10 py-24 md:py-32">
            <div className="max-w-4xl">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight tracking-tight text-left">
                SAVE, EARN REWARDS, AND CHILL —
                <br />
                YOUR MONEY'S GROWING IN THE BACKGROUND.
              </h1>
              
              <p className="text-xl md:text-2xl mb-12 text-left">
                2% Monthly Returns. Capital-Safe. Effortless.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-start">
                <a href="https://2pc-mvp-sandbox-baef4547.vercel.app/login" target="_blank" rel="noopener noreferrer">
                  <Button 
                    size="lg" 
                    className="bg-[#5D5FEF] hover:bg-[#4A4CD8] text-white rounded-full px-8 py-6 text-lg font-medium h-auto w-full sm:w-auto"
                  >
                    EXPLORE THE PRODUCT
                  </Button>
                </a>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-[#5D5FEF] text-[#5D5FEF] hover:bg-[#5D5FEF]/10 rounded-full px-8 py-6 text-lg font-medium h-auto w-full sm:w-auto"
                >
                  VIEW PRODUCT DEMO
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="how-it-works" className="container py-20 md:py-28">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-[#5D5FEF]">
            HOW IT WORKS
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <Card className="card text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8 flex flex-col items-center">
                <div className="relative w-full h-48 mb-6">
                  <Image 
                    src="/frame-50-m8zi3tw1.png" 
                    alt="Set a Goal" 
                    fill
                    style={{ objectFit: "contain" }} 
                  />
                </div>
                <h3 className="text-2xl font-bold mb-3">Set a Goal</h3>
                <p className="text-lg">Dream trip, new kicks, or peace of mind.</p>
              </CardContent>
            </Card>
            
            <Card className="card text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8 flex flex-col items-center">
                <div className="relative w-full h-48 mb-6">
                  <Image 
                    src="/image-1-m8zicg5w.png" 
                    alt="Pick Your Saving Style" 
                    fill
                    style={{ objectFit: "contain" }} 
                  />
                </div>
                <h3 className="text-2xl font-bold mb-3">Pick Your Saving Style</h3>
                <p className="text-lg">Daily. Monthly. Lump Sum. Your choice.</p>
              </CardContent>
            </Card>
            
            <Card className="card text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8 flex flex-col items-center">
                <div className="relative w-full h-48 mb-6">
                  <Image 
                    src="/image-2-m8zicl3s.png" 
                    alt="Watch It Grow" 
                    fill
                    style={{ objectFit: "contain" }} 
                  />
                </div>
                <h3 className="text-2xl font-bold mb-3">Watch It Grow</h3>
                <p className="text-lg">2% monthly + Coin cashback. Chill and earn.</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Calculator Section */}
        <section id="calculator" className="container py-20 md:py-28">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-[#5D5FEF]">
            SEE YOUR POTENTIAL
          </h2>
          <p className="text-xl md:text-2xl text-center mb-16 max-w-3xl mx-auto">
            Let Your ₹10/Day Grow Into Something Massive Over Time.
            <br />
            This Calculator Shows How Your Money Compounds With 2% Monthly Returns.
          </p>
          
          <Card className="p-10 rounded-2xl shadow-lg">
            <CardContent className="p-6">
              <Calculator />
            </CardContent>
          </Card>
        </section>

        {/* What Makes 2PC Different Section */}
        <section id="features" className="container py-20 md:py-28">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-[#5D5FEF]">
            WHAT MAKES 2PC DIFFERENT
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">₹10 TO START 💸</h3>
              <p className="text-lg">
                Start saving with just ₹10/day.
                <br />
                Yep, even your chai budget can build wealth.
              </p>
            </Card>
            
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">2% MONTHLY GAINS 📈</h3>
              <p className="text-lg">
                Earn a fixed 2% return every month.
                <br />
                It's like an FD, but smarter.
              </p>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">AUTO-UPI = AUTO-RICH</h3>
              <p className="text-lg">
                Set it once and forget it. We save daily/monthly via
                <br />
                UPI — totally hands-free.
              </p>
            </Card>
            
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">COIN DROPS 🎁</h3>
              <p className="text-lg">
                Every UPI payment gets you Coin rewards.
                <br />
                1 Coin = ₹1. Use them or withdraw them.
              </p>
            </Card>
          </div>
          
          <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
            <h3 className="text-2xl font-bold mb-3">BORROW FROM YOURSELF 🧠</h3>
            <p className="text-lg">
              Need a loan? Get one instantly from your own saved money.
              <br />
              No interest. No paperwork. Just peace of mind.
            </p>
          </Card>
        </section>

        {/* Why 2PC is Built to Scale Section */}
        <section id="why-2pc" className="container py-20 md:py-28">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 text-[#5D5FEF]">
            WHY 2PC IS BUILT TO SCALE
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">🚀 MASSIVE TARGET AUDIENCE</h3>
              <p className="text-lg">
                India's 400M+ young adults need simple savings tools — 2PC fits right into their 
                lifestyle and daily spending habits.
              </p>
            </Card>
            
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">🧠 BEHAVIOR-DRIVEN DESIGN</h3>
              <p className="text-lg">
                We don't just ask people to save — we nudge, reward, and build habits that stick
                using proven behavior models.
              </p>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-10">
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">🎮 GAMIFIED WITH COINS</h3>
              <p className="text-lg">
                Our Coin system adds instant gratification. It's not just cashback — it's
                a reason to come back.
              </p>
            </Card>
            
            <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-3">🔒 TRUST-BUILT GROWTH</h3>
              <p className="text-lg">
                2% monthly returns. FD-like security. Perfect for first-time savers who want
                growth without risk.
              </p>
            </Card>
          </div>
          
          <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
            <h3 className="text-2xl font-bold mb-3">🔄 HIGH FREQUENCY = HIGH LIFETIME VALUE</h3>
            <p className="text-lg">
              Daily interactions → better habit loops → higher retention, engagement, and
              future cross-sell opportunities.
            </p>
          </Card>
          
          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center mt-16">
            <a href="https://2pc-mvp-sandbox-baef4547.vercel.app/login" target="_blank" rel="noopener noreferrer">
              <Button 
                size="lg" 
                className="bg-[#5D5FEF] hover:bg-[#4A4CD8] text-white rounded-full px-8 py-6 text-lg font-medium h-auto w-full sm:w-auto"
              >
                EXPLORE THE PRODUCT
              </Button>
            </a>
            <Button 
              variant="outline" 
              size="lg" 
              className="border-[#5D5FEF] text-[#5D5FEF] hover:bg-[#5D5FEF]/10 rounded-full px-8 py-6 text-lg font-medium h-auto w-full sm:w-auto"
            >
              VIEW PRODUCT DEMO
            </Button>
          </div>
        </section>

        {/* Be Part of Savings Revolution Section */}
        <section id="join-us" className="container py-20 md:py-28 bg-gradient-to-br from-white to-[#F0EEFF] rounded-3xl mb-10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-[#5D5FEF]">
              💡 BE PART OF <br />SAVINGS REVOLUTION.
            </h2>
            
            <p className="text-xl md:text-2xl mb-16 max-w-3xl mx-auto">
              2PC is more than an app — it's a movement to make saving cool, consistent, 
              and rewarding for everyone. Whether you're an investor, a partner, or just 
              curious — this is the perfect time to get in early.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-12">
              <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
                <h3 className="text-2xl font-bold mb-3">🔹 INVEST OR PARTNER</h3>
                <p className="text-lg mb-8">
                  Back a habit-forming platform with real traction, strong retention loops, and 
                  mass-market potential. Let's build a future where money grows effortlessly.
                </p>
                <div className="flex justify-center">
                  <a href="mailto:vini12345@gmail.com">
                    <Button className="bg-[#5D5FEF] hover:bg-[#4A4CD8] text-white rounded-full px-6 py-3">
                      ✉️ vini12345@gmail.com
                    </Button>
                  </a>
                </div>
              </Card>
              
              <Card className="bg-white rounded-2xl p-10 text-center hover:shadow-xl transition-all duration-300">
                <h3 className="text-2xl font-bold mb-3">🔹 TRY 2PC NOW</h3>
                <p className="text-lg mb-8">
                  Experience the MVP. Save ₹10 today, earn 2% monthly, and get rewarded for just 
                  being consistent.
                </p>
                <div className="flex justify-center">
                  <a href="https://2pc-mvp-sandbox-baef4547.vercel.app/login" target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#5D5FEF] hover:bg-[#4A4CD8] text-white rounded-full px-6 py-3">
                      🚀 Try 2PC Now
                    </Button>
                  </a>
                </div>
              </Card>
            </div>
          </div>
        </section>
        
        {/* Footer */}
        <footer className="container py-8 text-center">
          <p className="text-sm text-gray-600">
            ©2025 2PC. All rights reserved.
          </p>
        </footer>
      </main>
    </>
  )
}
