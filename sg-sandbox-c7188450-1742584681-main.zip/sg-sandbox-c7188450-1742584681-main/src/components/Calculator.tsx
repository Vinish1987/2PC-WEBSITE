
import React, { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"

export default function Calculator() {
  const [amount, setAmount] = useState<string>("10")
  const [contributionType, setContributionType] = useState<string>("daily")
  const [duration, setDuration] = useState<number>(2)
  const [finalAmount, setFinalAmount] = useState<number>(0)

  useEffect(() => {
    calculateGrowth()
  }, [amount, contributionType, duration])

  const calculateGrowth = () => {
    const monthlyRate = 0.02
    const amountNum = parseFloat(amount) || 0
    let totalMonths = duration * 12
    let total = 0

    if (contributionType === "lump") {
      // Lump sum calculation
      total = amountNum * Math.pow(1 + monthlyRate, totalMonths)
    } else {
      // Regular contribution calculation
      let monthlyContribution = amountNum
      if (contributionType === "daily") {
        monthlyContribution = amountNum * 30 // Approximate days in a month
      }

      for (let i = 0; i < totalMonths; i++) {
        total = (total + monthlyContribution) * (1 + monthlyRate)
      }
    }

    setFinalAmount(Math.round(total))
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="space-y-8">
        <div>
          <label className="text-xl font-medium mb-2 block">Contribution</label>
          <Input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="text-xl h-12 rounded-xl"
            placeholder="Rs 10"
          />
        </div>

        <div className="space-y-4">
          <label className="text-xl font-medium block">Contribution Type</label>
          <div className="flex space-x-4">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="contributionType"
                checked={contributionType === "daily"}
                onChange={() => setContributionType("daily")}
                className="h-5 w-5 accent-[#5D5FEF]"
              />
              <span>Daily</span>
            </label>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="contributionType"
                checked={contributionType === "monthly"}
                onChange={() => setContributionType("monthly")}
                className="h-5 w-5 accent-[#5D5FEF]"
              />
              <span>Monthly</span>
            </label>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="radio"
                name="contributionType"
                checked={contributionType === "lump"}
                onChange={() => setContributionType("lump")}
                className="h-5 w-5 accent-[#5D5FEF]"
              />
              <span>Lump Sum</span>
            </label>
          </div>
        </div>

        <div className="space-y-4">
          <label className="text-xl font-medium block">Duration</label>
          <Slider
            defaultValue={[2]}
            min={1}
            max={10}
            step={1}
            onValueChange={(value) => setDuration(value[0])}
            className="py-4"
          />
          <div className="text-lg">{duration} years</div>
        </div>
      </div>

      <Card className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <CardContent className="p-8">
          <h3 className="text-2xl font-bold mb-6">Graph</h3>
          <div className="flex flex-col items-center justify-center h-48 bg-[#F8F8FF] rounded-xl p-4">
            <div className="text-4xl font-bold text-[#5D5FEF]">₹{finalAmount.toLocaleString()}</div>
            <p className="text-lg mt-2">Total after {duration} years</p>
          </div>
          <div className="mt-6 text-center">
            <p className="text-lg">
              Your {contributionType === "daily" ? "daily" : contributionType === "monthly" ? "monthly" : "one-time"} contribution of ₹{amount} will grow to ₹{finalAmount.toLocaleString()} in {duration} years with 2% monthly returns.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
